%
% check dijkstra for only positive values
%
% write graph xml reader
%
% add graph struct type...
%
% read through "header" comments and make sure they refer to the correct
% data
%
% ctrl-c mex files
%
% add runtimes to all files
% 

fprintf('Wanna help?  Send me email!');