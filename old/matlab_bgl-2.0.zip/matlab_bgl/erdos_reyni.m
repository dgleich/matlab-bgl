function A=erdos_reyni(n,p)
% ERDOS_REYNI Generates a random Erdos-Reyni (Gnp) graph
%
% A=erdos_reyni(n,p) generates a random Gnp graph with n vertices and where
% the probability of each edge is p.  The resulting graph is symmetric.
%
% This function is different from the Boost Graph library version, it was
% reimplemented natively in Matlab.
%
% Example:
%   A = erdos_reyni(100,0.05);

%
% David Gleich
% 21 May 2006
%

A = triu(rand(n),1)<p;
A = sparse(A);
A = A+A';

