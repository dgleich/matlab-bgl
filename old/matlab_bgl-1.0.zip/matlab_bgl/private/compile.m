clear mex

mbglfiles = {'bfs_mex.c', 'dfs_mex.c', 'biconnected_components_mex.c', ...
	     'components_mex.c', 'matlab_bgl_sp_mex.c', ...
	     'matlab_bgl_all_sp_mex.c', ...
	     'mst_mex.c', 'clustering_coefficients_mex.c', ...
	     'betweenness_centrality_mex.c', ...
	     'max_flow_mex.c'};
	     
if (ispc)
    % must change /MD to /ML in mexopts.bat
	mexflags = '-O -I..\libmbgl\include LINKFLAGS#''$LINKFLAGS -libpath:..\libmbgl\Release'' LINKFLAGSPOST#''$LINKFLAGSPOST libmbgl.lib''';
else

	c = computer;
	mexflags = '-O -I../libmbgl/include -L../libmbgl';
	if (strcmp(c,'GLNXA64'))
	     mexflags = [mexflags ' -lmbgl64'];
	else
		mexflags = [mexfalgs ' -lmbgl'];
	end;
end;

for (file = mbglfiles)
     mexstr = ['mex ' mexflags ' ' char(file)];
     fprintf('%s\n', mexstr);
     eval(mexstr);
end;

