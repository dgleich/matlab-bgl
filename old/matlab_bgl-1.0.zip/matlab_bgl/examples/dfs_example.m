load ../graphs/dfs_example.mat
[d dt ft pred] = bfs(A,2);
[ignore order] = sort(dt);
labels(order)


