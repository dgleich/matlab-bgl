%
% check returns of dfs and bfs in the case of disconnected components.
%
% check dijkstra for only positive values
% 
% check for correct returns from biconnected components
%
% write graph xml reader
%
% add graph struct type...
%
% read through "header" comments and make sure they refer to the correct
% data
%
% check for sparse/dense types
%
% ctrl-c mex files
%
% add runtimes to all files
% 
% add 