function [trans check] = get_matlab_bgl_options(options);
% 
% Internal private function.
%

doptions = set_matlab_bgl_default();
if (nargin>0)
    options = merge_structs(options, doptions);
else
    options = doptions;
end;

trans = ~options.istrans;
check = ~options.nocheck;
